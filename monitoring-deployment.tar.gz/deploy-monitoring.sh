#!/bin/bash
# deploy-monitoring.sh - Deploy monitoring to production servers

set -e

echo "=== Deploying User Activity Monitoring ==="
echo "Server: $(hostname)"

# Replace HOSTNAME_PLACEHOLDER with actual hostname
sed "s/HOSTNAME_PLACEHOLDER/$(hostname)/g" promtail-config.yml > /tmp/promtail-config-deployed.yml

# Create directories
sudo mkdir -p /etc/promtail
sudo mkdir -p /etc/audit/rules.d

# Copy promtail config
sudo cp /tmp/promtail-config-deployed.yml /etc/promtail/promtail-config.yml

# Copy audit rules
sudo cp audit-rules.rules /etc/audit/rules.d/audit-rules.rules

# Reload audit rules
sudo augenrules --load

# Restart auditd
sudo systemctl restart auditd

# Restart promtail if running
if systemctl is-active --quiet promtail; then
    sudo systemctl restart promtail
    echo "✓ Promtail restarted"
else
    echo "⚠ Promtail not running. Start it with: sudo systemctl start promtail"
fi

echo "✓ Deployment complete for $(hostname)"
echo "✓ Audit rules loaded: $(sudo auditctl -l | wc -l)"
echo "✓ Check Grafana: {job=\"audit\", hostname=\"$(hostname)\"}"
